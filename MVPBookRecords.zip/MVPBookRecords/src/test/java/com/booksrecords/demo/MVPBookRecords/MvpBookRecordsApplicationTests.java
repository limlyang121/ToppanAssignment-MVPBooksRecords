package com.booksrecords.demo.MVPBookRecords;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvpBookRecordsApplicationTests {

	@Test
	void contextLoads() {
	}

}
